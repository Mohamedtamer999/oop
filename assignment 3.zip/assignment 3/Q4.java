/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.q4;

import java.util.Scanner;

/**
 *
 * @author pc
 */
public class Q4 {

    public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        int sum = 0;
        int count = 0;

        int num = scanner.nextInt();
        while (num != 0) {
            if (num > 0) {
                if (num > max) {
                    max = num;
                }
                if (num < min) {
                    min = num;
                }
                sum += num;
                count++;
            }
            num = scanner.nextInt();
        }

        if (count > 0) {
            double average = (double) sum / count;
            System.out.println("Largest: " + max);
            System.out.println("Smallest: " + min);
            System.out.println("Average: " + average);
        } else {
            System.out.println("No positive numbers were entered.");
        }

        scanner.close();
    }
} 
    
