/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.q6;

/**
 *
 * @author pc
 */
public class Q6 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
