/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject23;

/**
 *
 * @author pc
 */
public class Mavenproject23 {

    public static void main(String[] args) {
        Student s1 = new Student("101", "Alice", 3.2);
        Student s2 = new Student();

        s2.setGPA(3.8);

        System.out.println("Student 1: ID=" + s1.getStudentID() + ", Name=" + s1.getStudentName() + ", GPA=" + s1.getGPA());
        System.out.println("Is Honor Student: " + s1.isHonorStudent());

        System.out.println("Student 2: ID=" + s2.getStudentID() + ", Name=" + s2.getStudentName() + ", GPA=" + s2.getGPA());
        System.out.println("Is Honor Student: " + s2.isHonorStudent());
    }
}
    

